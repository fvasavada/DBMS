package lms.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.awt.event.ActionEvent;

public class SignUp extends JFrame {

	private JPanel ctpSignUpContent;
	private JTextField txtSsn;
	private JTextField txtlastName;
	private JTextField txtFirstName;
	private JTextField txtPhone;
	private JTextField txtAddress;
	private JButton btnMaybeLater;
	private JButton btnRegister;

	static Connection jdbcConnection;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp frame = new SignUp();
					frame.setVisible(true);
					frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
							dim.height / 2 - frame.getSize().height / 2);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignUp() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(SignUp.class.getResource("/lms/resources/bat.png")));
		setTitle("Welcome | Add User Account");
		initComponents();
		createEvents();

	}

	private void createEvents() {
		// TODO Auto-generated method stub
		btnMaybeLater.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Welcome welcomePg = new Welcome();
				welcomePg.setVisible(true);
				Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				welcomePg.setLocation(dim.width / 2 - welcomePg.getSize().width / 2,
						dim.height / 2 - welcomePg.getSize().height / 2);
			}
		});

		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Code to Validate the User Details & Create a new account
				jdbcConnection = null;
				boolean recordFound = false;
				boolean cardNumConflict = false;
				String newCardNo = "";
				//
				try {
					jdbcConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "########");

					// Create a SQL statement object and execute the query.
					if (txtFirstName.getText().equals("") || txtlastName.getText().equals("")
							|| txtAddress.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "First Name, Last Name, SSN and Address are Required !");
					} else {
						// check for valid Ssn format
						if (txtSsn.getText().matches("\\d{3}-\\d{2}-\\d{4}")) {
							Statement stmt = jdbcConnection.createStatement();
							stmt.executeQuery("use library;");
							ResultSet rs = stmt.executeQuery("SELECT * FROM borrower;");
							// Generate the Next ID Card Number
							Statement stmt1 = jdbcConnection.createStatement();
							// Generate the new Card Number
							ResultSet rs1 = stmt1.executeQuery("SELECT * FROM borrower ORDER BY card_no DESC LIMIT 1;");
							while (rs1.next()) {
								String tempStr = rs1.getString("card_no");
								int tempId = Integer.parseInt(tempStr.substring(2));
								newCardNo = "ID" + String.format("%06d", (tempId + 1));
								System.out.println("newCardNo ID:  " + newCardNo);
							}
							// Iterate through the result set.
							while (rs.next()) {
								// Keep track of the line/tuple count
								String card_no, ssn, fname, lname, address, phone;
								card_no = rs.getString("card_no");
								ssn = rs.getString("ssn");
								fname = rs.getString("fname");
								lname = rs.getString("lname");
								address = rs.getString("address");
								phone = rs.getString("phone");
								if ((ssn.equals(txtSsn.getText()))) {
									recordFound = true;
									if (newCardNo.equals(card_no)) {
										cardNumConflict = true;
									}
									break;
								}
							}
							// End while(rs.next())
							// Always close the recordset and connection.
							if (recordFound) {
								JOptionPane.showMessageDialog(null,
										"User Exists!!! One Card Issued per User. Thank You !");
							} else {
								if (!cardNumConflict) {
									stmt.executeUpdate("INSERT INTO borrower VALUES(\"" + newCardNo + "\",\""
											+ txtSsn.getText() + "\",\"" + txtFirstName.getText() + "\",\""
											+ txtlastName.getText() + "\",\"" + txtAddress.getText() + "\",\""
											+ txtPhone.getText() + "\");");
									JOptionPane.showMessageDialog(null,
											"User successfully created!!! Your Card ID is " + newCardNo);
								} else {
									JOptionPane.showMessageDialog(null, "Card ID Conflict: " + newCardNo);
								}
								dispose();
								// Show the LMS Sign On Window.
								Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
								UserLogOn logOnPg = new UserLogOn();
								logOnPg.setVisible(true);
								logOnPg.setLocation(dim.width / 2 - logOnPg.getSize().width / 2,
										dim.height / 2 - logOnPg.getSize().height / 2);
							}
							rs.close();
							rs1.close();
							jdbcConnection.close();
						} else {
							JOptionPane.showMessageDialog(null,
									"The Social Security Number Format Mismatch ! (DDD-DD-DDDD)");
						}

					}
				} catch (SQLException ex) {
					System.out.println("Error in connection: " + ex.getMessage());
				}
			}
		});
	}

	private void initComponents() {
		// TODO Auto-generated method stub
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		ctpSignUpContent = new JPanel();
		ctpSignUpContent.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(ctpSignUpContent);

		JLabel lblWecomeMsg = new JLabel("Welcome, Please Enter Your Personal Details To Register With Us");

		JLabel lblFirstName = new JLabel("First Name:");

		JLabel lblLastName = new JLabel("Last Name:");

		JLabel lblSocialSecurityNumber = new JLabel("Social Security Number:");

		JLabel lblAddress = new JLabel("Address:");

		JLabel lblPhone = new JLabel("Phone #:");

		txtSsn = new JTextField();
		txtSsn.setToolTipText("Please Enter 9 Digit SSN");
		txtSsn.setColumns(10);

		txtlastName = new JTextField();
		txtlastName.setColumns(10);

		txtFirstName = new JTextField();
		txtFirstName.setColumns(10);

		txtPhone = new JTextField();
		txtPhone.setColumns(10);

		txtAddress = new JTextField();
		txtAddress.setColumns(10);

		btnRegister = new JButton("Register");

		btnMaybeLater = new JButton("Maybe Later !");

		GroupLayout gl_ctpSignUpContent = new GroupLayout(ctpSignUpContent);
		gl_ctpSignUpContent
				.setHorizontalGroup(
						gl_ctpSignUpContent.createParallelGroup(Alignment.LEADING)
								.addGroup(
										gl_ctpSignUpContent.createSequentialGroup().addGap(22)
												.addGroup(gl_ctpSignUpContent.createParallelGroup(Alignment.LEADING)
														.addGroup(gl_ctpSignUpContent
																.createSequentialGroup().addComponent(
																		btnRegister)
																.addGap(18).addComponent(btnMaybeLater).addGap(222))
														.addGroup(gl_ctpSignUpContent.createSequentialGroup()
																.addGroup(gl_ctpSignUpContent
																		.createParallelGroup(Alignment.LEADING)
																		.addComponent(lblWecomeMsg)
																		.addGroup(gl_ctpSignUpContent
																				.createSequentialGroup()
																				.addGroup(gl_ctpSignUpContent
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addComponent(
																								lblSocialSecurityNumber)
																						.addComponent(lblLastName)
																						.addComponent(lblFirstName)
																						.addComponent(lblPhone)
																						.addComponent(lblAddress))
																				.addPreferredGap(
																						ComponentPlacement.RELATED)
																				.addGroup(gl_ctpSignUpContent
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addComponent(txtFirstName,
																								GroupLayout.DEFAULT_SIZE,
																								195, Short.MAX_VALUE)
																						.addComponent(txtlastName,
																								GroupLayout.DEFAULT_SIZE,
																								195, Short.MAX_VALUE)
																						.addComponent(txtSsn,
																								GroupLayout.DEFAULT_SIZE,
																								195, Short.MAX_VALUE)
																						.addComponent(txtAddress,
																								GroupLayout.DEFAULT_SIZE,
																								195, Short.MAX_VALUE)
																						.addComponent(txtPhone,
																								GroupLayout.DEFAULT_SIZE,
																								195, Short.MAX_VALUE))))
																.addGap(90)))));
		gl_ctpSignUpContent.setVerticalGroup(gl_ctpSignUpContent.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_ctpSignUpContent.createSequentialGroup().addGap(23).addComponent(lblWecomeMsg).addGap(18)
						.addGroup(gl_ctpSignUpContent.createParallelGroup(Alignment.BASELINE).addComponent(lblFirstName)
								.addComponent(txtFirstName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addGroup(gl_ctpSignUpContent.createParallelGroup(Alignment.BASELINE).addComponent(lblLastName)
								.addComponent(txtlastName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addGroup(gl_ctpSignUpContent.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblSocialSecurityNumber).addComponent(txtSsn, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addGroup(gl_ctpSignUpContent.createParallelGroup(Alignment.BASELINE).addComponent(lblAddress)
								.addComponent(txtAddress, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addGroup(gl_ctpSignUpContent.createParallelGroup(Alignment.BASELINE).addComponent(lblPhone)
								.addComponent(txtPhone, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(18)
						.addGroup(gl_ctpSignUpContent.createParallelGroup(Alignment.BASELINE).addComponent(btnRegister)
								.addComponent(btnMaybeLater))
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		ctpSignUpContent.setLayout(gl_ctpSignUpContent);
	}
}
