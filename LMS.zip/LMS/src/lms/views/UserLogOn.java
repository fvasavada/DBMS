package lms.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class UserLogOn extends JFrame {

	private JPanel contentPane;
	private JTextField txtIdCardNum;
	private JButton btnLogOn;
	private JButton btnMaybeLater;
	static Connection jdbcConnection;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserLogOn frame = new UserLogOn();
					frame.setVisible(true);
					frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
							dim.height / 2 - frame.getSize().height / 2);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserLogOn() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(UserLogOn.class.getResource("/lms/resources/bat.png")));
		setTitle("Cardholder Log On");

		initComponents();
		createEvents();

	}

	private void createEvents() {
		// TODO Auto-generated method stub
		btnLogOn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Validate the ID Card Number &
				// Proceed to Main Screen
				jdbcConnection = null;
				boolean recordFound = false;

				try {
					jdbcConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "########");

					// Create a SQL statement object and execute the query.
					if (/* txtUserName.getText().equals("") || */ txtIdCardNum.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "Please Enter Complete Details. Thank You !");
					} else {

						Statement stmt = jdbcConnection.createStatement();
						stmt.executeQuery("use library;");
						ResultSet rs = stmt.executeQuery("SELECT * FROM borrower;");
						String card_no, ssn, fname = "", lname;
						// Iterate through the result set.
						while (rs.next()) {
							// Keep track of the line/tuple count

							card_no = rs.getString("card_no");
							fname = rs.getString("fname");
							lname = rs.getString("lname");
							if ((card_no.equals(txtIdCardNum.getText()))) {
								recordFound = true;
								break;
							}
						}
						if (recordFound) {
							// JOptionPane.showMessageDialog(null, "Log On
							// Successful, Welcome "+fname+"!");
							// Call the Main LMS page
							dispose();
							Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
							lmsMain main = new lmsMain(txtIdCardNum.getText(), fname);
							main.setVisible(true);
							main.setLocation(dim.width / 2 - main.getSize().width / 2,
									dim.height / 2 - main.getSize().height / 2);
						} else {
							JOptionPane.showMessageDialog(null,
									"Please Enter Valid Credentials OR Create a New Account!");
						}
						rs.close();
						jdbcConnection.close();
					}
				} catch (SQLException ex) {
					System.out.println("Error in connection: " + ex.getMessage());
				}
			}
		});
		btnMaybeLater.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Go back to Welcome Screen
				dispose();
				Welcome welcomePg = new Welcome();
				welcomePg.setVisible(true);
				Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				welcomePg.setLocation(dim.width / 2 - welcomePg.getSize().width / 2,
						dim.height / 2 - welcomePg.getSize().height / 2);
			}
		});
	}

	private void initComponents() {
		// TODO Auto-generated method stub

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblWelcomeMsg = new JLabel("Welcome, Please Enter ID Card # to Proceede.");
		lblWelcomeMsg.setFont(new Font("Tahoma", Font.PLAIN, 12));

		JLabel lblIdCard = new JLabel("ID Card #:");
		lblIdCard.setFont(new Font("Tahoma", Font.PLAIN, 12));

		txtIdCardNum = new JTextField();
		txtIdCardNum.setColumns(10);

		btnLogOn = new JButton("Log On");
		btnLogOn.setFont(new Font("Tahoma", Font.PLAIN, 12));

		btnMaybeLater = new JButton("Maybe Later!");
		btnMaybeLater.setFont(new Font("Tahoma", Font.PLAIN, 12));

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane
				.setHorizontalGroup(
						gl_contentPane
								.createParallelGroup(
										Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup().addContainerGap()
										.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
												.addGroup(gl_contentPane.createSequentialGroup()
														.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
																.addComponent(lblWelcomeMsg)
																.addGroup(gl_contentPane.createSequentialGroup()
																		.addComponent(btnLogOn).addGap(18).addComponent(
																				btnMaybeLater)))
														.addGap(126))
												.addGroup(gl_contentPane.createSequentialGroup()
														.addComponent(lblIdCard, GroupLayout.DEFAULT_SIZE, 76,
																Short.MAX_VALUE)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(txtIdCardNum, GroupLayout.DEFAULT_SIZE, 179,
																Short.MAX_VALUE)
														.addGap(155)))));
		gl_contentPane
				.setVerticalGroup(
						gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(
										gl_contentPane.createSequentialGroup().addContainerGap()
												.addComponent(lblWelcomeMsg).addGap(49)
												.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
														.addComponent(lblIdCard, GroupLayout.PREFERRED_SIZE, 27,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(txtIdCardNum, GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
												.addPreferredGap(ComponentPlacement.RELATED, 108, Short.MAX_VALUE)
												.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
														.addComponent(btnLogOn).addComponent(btnMaybeLater))
												.addGap(19)));
		contentPane.setLayout(gl_contentPane);
	}

}
