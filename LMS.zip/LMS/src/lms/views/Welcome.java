package lms.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.Closeable;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Welcome extends JFrame {

	private JPanel ctpMainContent;
	private JButton btnSignUp;
	private JButton btnSignOn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Welcome frame = new Welcome();
					frame.setVisible(true);
					frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
							dim.height / 2 - frame.getSize().height / 2);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Welcome() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Welcome.class.getResource("/lms/resources/bat.png")));

		createEvents();
		initComponents();
	}

	private void createEvents() {
		// TODO Auto-generated method stub
		setTitle("Welcome to Library Management System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		ctpMainContent = new JPanel();
		ctpMainContent.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(ctpMainContent);

		JLabel lblWelcomeToLibrary = new JLabel("Welcome to Library Management System !");
		lblWelcomeToLibrary.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblWelcomeToLibrary.setHorizontalAlignment(SwingConstants.CENTER);

		JLabel lblWhatWouldYou = new JLabel("What would you like to do today ?");
		lblWhatWouldYou.setFont(new Font("Tahoma", Font.PLAIN, 12));

		btnSignUp = new JButton("Create New User Account !");
		btnSignUp.setFont(new Font("Tahoma", Font.PLAIN, 12));

		btnSignOn = new JButton("Cardholder's Account Log on !");
		btnSignOn.setFont(new Font("Tahoma", Font.PLAIN, 12));

		GroupLayout gl_ctpMainContent = new GroupLayout(ctpMainContent);
		gl_ctpMainContent.setHorizontalGroup(gl_ctpMainContent.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_ctpMainContent.createSequentialGroup().addGap(22)
						.addGroup(gl_ctpMainContent.createParallelGroup(Alignment.LEADING, false)
								.addComponent(btnSignOn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE)
								.addComponent(lblWhatWouldYou).addComponent(btnSignUp, GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addContainerGap(111, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_ctpMainContent.createSequentialGroup()
						.addContainerGap(87, Short.MAX_VALUE).addComponent(lblWelcomeToLibrary).addGap(76)));
		gl_ctpMainContent.setVerticalGroup(gl_ctpMainContent.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_ctpMainContent.createSequentialGroup().addGap(36).addComponent(lblWelcomeToLibrary)
						.addGap(40).addComponent(lblWhatWouldYou).addGap(18).addComponent(btnSignUp).addGap(18)
						.addComponent(btnSignOn).addContainerGap(65, Short.MAX_VALUE)));
		ctpMainContent.setLayout(gl_ctpMainContent);
	}

	private void initComponents() {
		// TODO Auto-generated method stub
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				SignUp signUpPg = new SignUp();
				signUpPg.setVisible(true);
				Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				signUpPg.setLocation(dim.width / 2 - signUpPg.getSize().width / 2,
						dim.height / 2 - signUpPg.getSize().height / 2);
			}
		});
		btnSignOn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				// Show the LMS Sign In Window.
				UserLogOn logOnPg = new UserLogOn();
				Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				logOnPg.setVisible(true);
				logOnPg.setLocation(dim.width / 2 - logOnPg.getSize().width / 2,
						dim.height / 2 - logOnPg.getSize().height / 2);
			}
		});
	}

}
